# Smart Shopping - AACC Assignment 1

**Status:** architecture proposal; not an implemented / deployed system.

## Submit this

The human-readable PDF `Smart_Shopping_Assignment_1.pdf` and the University GitHub repository URL. The PDF currently contains a **REPLACE ME** marker because the actual university repository URL has not been supplied. **Do not submit the placeholder PDF as-is.**

1. Create the repository in your university GitHub environment.
2. Push the contents of this folder, including `.puml` files, ADRs, and the PDF.
3. Replace the PDF cover placeholder using the included helper: `python tools/set_repository_url.py https://github.com/YOUR_UNIVERSITY_USER/YOUR_REPOSITORY` (requires `pip install pymupdf`), or provide the URL for a revised PDF. This creates `Smart_Shopping_Assignment_1_READY.pdf` with a **clickable** link.
4. Open the link in a private/incognito window (or with an authorized university account) and ensure the instructor has access.
5. Upload `Smart_Shopping_Assignment_1_READY.pdf` to the course submission platform.

## Materials

- `docs/project-specification.md`: scope, features, NFR targets, assumptions.
- `docs/significant-use-cases.md`: architecturally significant use cases and alternatives.
- `docs/architecture.md`: decomposition, interfaces, data flow, Kubernetes alignment.
- `docs/diagrams/*.puml`: **PlantUML source** for use case, two sequences, component, deployment and optional class model.
- `docs/diagrams/previews/*.png`: explanatory previews. Authoritative source is each `.puml` file.
- `docs/adr/ADR-*.md`: architectural decision records.
- `docs/verification-plan.md`: acceptance checks and experiments for later implementation.
- `docs/references.md`: provided course sources, distinguishing constraints from proposed design.

## First milestone vs future work

Assignment 1: specification, important use cases, diagrams and ADRs. Future milestones: implementation, Kubernetes deployment, automated tests, observability, carbon experiments and presentation. No achievement metrics or deployed functionality are claimed in this package.

## Model and data constraints

Course Overview: **no training or fine-tuning**. The design uses an existing forecasting component or a non-trained baseline, with versioning and explicit fallback. Price data can be authorized provider data or clearly marked synthetic/CSV demo data. Product carbon footprint is **out of scope**; only computation-related carbon is estimated.
