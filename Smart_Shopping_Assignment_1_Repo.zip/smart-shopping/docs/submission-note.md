# Submission metadata

**Repository:** [INSERT YOUR UNIVERSITY GITHUB REPOSITORY URL HERE]

**Replace before final submission.** This PDF cannot contain a real university GitHub link until you provide it.

**PDF:** `Smart_Shopping_Assignment_1.pdf`

**UML files:** `docs/diagrams/*.puml`

**ADRs:** `docs/adr/ADR-*.md`
