#!/usr/bin/env python3
"""Replace the submission PDF's marked GitHub placeholder with a clickable real URL.
Usage: python tools/set_repository_url.py https://github.com/YOUR_UNIVERSITY_USER/YOUR_REPO
Dependency: pip install pymupdf
"""
from pathlib import Path
import argparse
from urllib.parse import urlparse
import fitz

PLACEHOLDER='[INSERT YOUR UNIVERSITY GITHUB REPOSITORY URL HERE]'

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('url',help='Your real university GitHub repository HTTPS URL')
    parser.add_argument('--input',default='Smart_Shopping_Assignment_1.pdf')
    parser.add_argument('--output',default='Smart_Shopping_Assignment_1_READY.pdf')
    args=parser.parse_args()
    u=urlparse(args.url)
    if u.scheme!='https' or not u.netloc or 'github' not in u.netloc.lower() or len(u.path.strip('/').split('/'))<2:
        raise SystemExit('Expected an HTTPS GitHub repository URL such as https://github.com/<account>/<repository>.')
    doc=fitz.open(args.input)
    page=doc[0]
    hits=page.search_for(PLACEHOLDER)
    if not hits:
        raise SystemExit('Could not find placeholder in PDF. The PDF may have been edited already.')
    rect=hits[0]
    if len(args.url)>80: raise SystemExit('URL too long for cover line; use a shorter canonical repo URL.')
    page.add_redact_annot(rect + (-1,-2,15,3),fill=(1,1,1))
    page.apply_redactions()
    font_size=9.1
    max_width=page.rect.width-2*51
    while fitz.get_text_length(args.url,fontname='helv',fontsize=font_size)>max_width and font_size>7:
        font_size-=.2
    y=rect.y1-1.4
    page.insert_text((51,y),args.url,fontname='helv',fontsize=font_size,color=(0.07,0.36,0.47))
    page.insert_link({'kind':fitz.LINK_URI,'from':fitz.Rect(49,rect.y0-1,page.rect.width-50,rect.y1+2),'uri':args.url})
    output=Path(args.output)
    doc.save(output,garbage=4,deflate=True)
    doc.close()
    print('Ready PDF:',output)

if __name__=='__main__': main()
